/**
 * foi usado chatgpt
 */

import java.util.*;

public class Main {
    static final int INF = Integer.MAX_VALUE;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Reading input
        int T = sc.nextInt();
        int B = sc.nextInt();
        int L = sc.nextInt();
        int R = sc.nextInt();

        // Initialize the capacity graph
        int[][] capacity = new int[L + 1][L + 1];

        // Read the roads and build the graph
        for (int i = 0; i < R; i++) {
            int l1 = sc.nextInt();
            int l2 = sc.nextInt();
            capacity[l1][l2] = 1;
            capacity[l2][l1] = 1; // Since the roads are bidirectional
        }

        // Read the vault and destination locations
        int lv = sc.nextInt();
        int ld = sc.nextInt();

        // Use the Edmonds-Karp algorithm to find the maximum number of disjoint paths
        int maxPaths = edmondsKarp(capacity, lv, ld, L);

        // Calculate the maximum possible number of stolen gold bars
        int maxGoldBars = maxPaths * B;

        // Print the result
        System.out.println(maxGoldBars);

        sc.close();
    }

    // BFS function to find if there is an augmenting path
    private static boolean bfs(int[][] capacity, int source, int sink, int[] parent, int nodes) {
        boolean[] visited = new boolean[nodes + 1];
        Queue<Integer> queue = new LinkedList<>();
        queue.add(source);
        visited[source] = true;
        parent[source] = -1;

        while (!queue.isEmpty()) {
            int u = queue.poll();

            for (int v = 1; v <= nodes; v++) {
                if (!visited[v] && capacity[u][v] > 0) {
                    queue.add(v);
                    parent[v] = u;
                    visited[v] = true;

                    if (v == sink)
                        return true;
                }
            }
        }
        return false;
    }

    // Edmonds-Karp algorithm to find the maximum flow
    private static int edmondsKarp(int[][] capacity, int source, int sink, int nodes) {
        int u, v;
        int[] parent = new int[nodes + 1];
        int maxFlow = 0;

        // Augment the flow while there is a path from source to sink
        while (bfs(capacity, source, sink, parent, nodes)) {
            // Find the maximum flow through the path found.
            int pathFlow = INF;
            for (v = sink; v != source; v = parent[v]) {
                u = parent[v];
                pathFlow = Math.min(pathFlow, capacity[u][v]);
            }

            // update capacities of the edges and reverse edges along the path
            for (v = sink; v != source; v = parent[v]) {
                u = parent[v];
                capacity[u][v] -= pathFlow;
                capacity[v][u] += pathFlow;
            }

            // Add path flow to overall flow
            maxFlow += pathFlow;
        }

        return maxFlow;
    }
}
